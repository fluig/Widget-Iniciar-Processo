var HelloWorld = SuperWidget.extend({
    message: null,

    init: function () {
    	
    	$('#NOME_SOLICITANTE_'+this.instanceId).val(WCMAPI.getUser());
    	$('#email_'+this.instanceId).val(WCMAPI.userEmail);
    	
    	var select = $('#tipoIncidente_'+this.instanceId);
    	var ds = DatasetFactory.getDataset('ds_tipoIncidente');
    	$.each(ds.values,function(k,v){
    		// k - sao as posicoes;
    		// v - objetos (retorno do dataset) 
    		select.append('<option value='+v["nmIncidente"] +'>'+v["nmIncidente"]+'</option>');
    		
    	});
    	
    },

    bindings: {
        local: {
            
            'abrirchamado' :['click_abrirChamado']
        }
    },

    abrirChamado : function(){
    		//recuperar dados do formulario da widget
    		var usuario = $('#NOME_SOLICITANTE_'+this.instanceId).val();
    		var email = $('#email_'+this.instanceId).val();
    		var ramal = $('#ramal_'+this.instanceId).val();
    		var departamento = $('#departamento_'+this.instanceId).val();
    		var tipo_incidente = $('#tipoIncidente_'+this.instanceId).val();
    		var dsIncidente =  $('#dsIncidente_'+this.instanceId).val();
    		
    		//template envelope XML
    		    var _xml = null;
			$.ajax({
						url : '/iniciarProcesso/resources/js/xmls/ECMWFEngineService_simpleStartProcess.xml',
						async : false,
						type : "get",
						datatype : "xml",
						success : function(xml) {
							_xml = $(xml)
						}

					});
			
			//Alterar os valores recuperados na variavel _xml
			_xml.find("companyId").text(WCMAPI.tenantCode);
			_xml.find("username").text("wcm.academy");
			_xml.find("password").text("wcm.academy");
			_xml.find("processId").text("HELP_DESK");
			_xml.find("comments").text('Processo inicializado atraves de WIDGET');
			
			//descricao do chamado 
			
			_xml.find("[name='name']").text(usuario);
			_xml.find("[name='email']").text(email);
			_xml.find("[name='ramal']").text(ramal);
			_xml.find("[name='departamento']").text(departamento);
			_xml.find("[name='tipo_incidente']").text(tipo_incidente);
			_xml.find("[name='dsIncidente']").text(dsIncidente);
			

			
			//Usar o metodo WCMAPI.Create para chamar o webservice
			WCMAPI.Create({
				url : "/webdesk/ECMWorkflowEngineService?wsdl",
				contentType : "text/xml",
				dataType : "xml",
				data : _xml[0],
				success : function(data) {
					console.log(data)
					var processoCriado = $(data).find("iProcess").text();
					console.log('Processo :'+processoCriado);
					FLUIGC.toast({
						title:'Aviso',
						message:'Processo '+processoCriado+' criado com sucesso',
						type:'success'
					});
				
				}
			})

    }
});